#include "Pila.h"
#include<string>

Libro::~Libro(){}

Libro::Libro(const Libro& other){}

Libro::Libro(char au[20],char ti[20], int pa[20]){
    this->autor=au;
    this->titulo=ti;
    this->paginas=pa;
}

Libro :: Libro (const Libro &librocopia){
    this->autor=librocopia.autor;
    this->titulo=librocopia.titulo;
    this->paginas=librocopia.paginas;
}

void Libro :: setAutor (string aut){
    this->autor=aut;
}

string Libro :: getAutor (){
    return this->autor;
}
void Libro :: setTitulo (string tit){
    this->titulo=tit;
}

string Libro :: getTitulo (){
    return this->titulo;
}
void Libro :: setPaginas (int pag){
    this->paginas=pag;
}

int Libro :: getPaginas (){
    return this->paginas;
}
