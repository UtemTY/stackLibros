#ifndef PILA_H
#define PILA_H
#include<string>

class Libro
{
    public:
        char autor[20], titulo[20]; int paginas;
        virtual ~Libro();
        Libro(const Libro& librocopia);

    protected:

    private:
    Libro ();
    Libro (char[20], char[20], int);
    void setAutor (char);
    char getAutor();
    void setTitulo(char);
    char getTitulo ();
    void setPaginas (int);
    int getPaginas ();
};

#endif // PILA_H
